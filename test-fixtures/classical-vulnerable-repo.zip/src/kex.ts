import crypto from 'crypto';

export function performECDHExchange() {
  const ecdh = crypto.createECDH('prime256v1');
  ecdh.generateKeys();
  return ecdh;
}
