import crypto from 'crypto';
import jwt from 'jsonwebtoken';

export function createServiceRSAKey() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
  });
  return { publicKey, privateKey };
}

export function signAuthToken(payload: any, privateKey: string) {
  return jwt.sign(payload, privateKey, { algorithm: 'RS256' });
}
