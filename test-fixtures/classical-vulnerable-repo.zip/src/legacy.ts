import crypto from 'crypto';

export function legacyHash(data: string) {
  return crypto.createHash('md5').update(data).digest('hex');
}
